# Triple Eagle Estates

## Signup behavior
- Signup does **not** send an email verification OTP.
- A unique 9-digit User ID is generated for every new account.
- The generated User ID is also the user's Promo/Referral Code.
- After successful signup, the account session is saved and the user is automatically redirected to `user.html`.
- Existing login and forgot-password/reset functionality remains available.

## Run
```bash
npm install
npm start
```
Then open the site at the port shown by the server.

## Live admin property posts
- `admin.html` and `user.html` use the same public live-post channel.
- A post published from the admin Post screen appears in the user property feed automatically within a few seconds.
- Every live post includes an `ENQUIRE NOW` button, including posts that contain only text or media.
- Keep the `TOPIC` value in both HTML files unchanged so the two pages stay connected.
