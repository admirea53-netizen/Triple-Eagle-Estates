require('dotenv').config();
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const nodemailer = require('nodemailer');

const ROOT = __dirname;
const DB_FILE = path.join(ROOT, 'data', 'db.json');
const PORT = Number(process.env.PORT || 3000);


const GMAIL_USER = String(process.env.GMAIL_USER || '').trim();
const GMAIL_APP_PASSWORD = String(process.env.GMAIL_APP_PASSWORD || '').replace(/\s+/g,'').trim();
let mailer = null;
if (GMAIL_USER && GMAIL_APP_PASSWORD) {
  mailer = nodemailer.createTransport({service:'gmail',auth:{user:GMAIL_USER,pass:GMAIL_APP_PASSWORD}});
}
async function sendCodeEmail(to, code, purpose){
  if (!mailer) throw new Error('Email service is not configured. Set GMAIL_USER and GMAIL_APP_PASSWORD.');
  const subject = purpose === 'reset' ? 'Triple Eagle Estates Password Reset Code' : 'Triple Eagle Estates Email Verification Code';
  const intro = purpose === 'reset' ? 'Use this code to reset your Triple Eagle Estates password.' : 'Use this code to verify your Triple Eagle Estates account.';
  await mailer.sendMail({from:GMAIL_USER,to,subject,text:`${intro}\n\nYour 6-digit code is: ${code}\n\nThis code expires in 10 minutes. If you did not request this, you can ignore this email.`,html:`<div style="font-family:Arial,sans-serif;line-height:1.6"><h2>Triple Eagle Estates</h2><p>${intro}</p><p style="font-size:30px;font-weight:700;letter-spacing:8px">${code}</p><p>This code expires in 10 minutes.</p></div>`});
}

function ensureDb(){
  const dir = path.dirname(DB_FILE);
  if(!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true});
  if(!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({users:[]},null,2));
}
function readDb(){ ensureDb(); try{return JSON.parse(fs.readFileSync(DB_FILE,'utf8'));}catch(e){return {users:[]};} }
function writeDb(db){ ensureDb(); const tmp=DB_FILE+'.tmp'; fs.writeFileSync(tmp,JSON.stringify(db,null,2)); fs.renameSync(tmp,DB_FILE); }
function cleanEmail(v){return String(v||'').trim().toLowerCase();}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){
  return new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,(err,key)=>err?reject(err):resolve({salt,hash:key.toString('hex')})));
}
function verifyPassword(password,salt,storedHash){
  return new Promise((resolve,reject)=>crypto.scrypt(password,salt,64,(err,key)=>{
    if(err)return reject(err);
    const a=Buffer.from(key.toString('hex'),'hex'), b=Buffer.from(storedHash,'hex');
    resolve(a.length===b.length && crypto.timingSafeEqual(a,b));
  }));
}
function makeUserId(db){
  let id;
  do { id=String(Math.floor(200000000 + Math.random()*799999999)); }
  while(db.users.some(u=>u.userId===id));
  return id;
}
function codeExpired(ts){return !ts || Date.now()-Number(ts)>10*60*1000;}
function publicUser(u){return {userId:u.userId,promoCode:u.promoCode,email:u.email,phone:u.phone||'',username:u.username||u.email.split('@')[0],verified:!!u.verified};}
function findReferrerByPromoCode(db,promoCode){
  const code=String(promoCode||'').trim();
  if(!code) return null;
  return db.users.find(u=>String(u.promoCode||u.userId||'').trim()===code)||null;
}
function json(res,status,data){const body=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Content-Length':Buffer.byteLength(body)});res.end(body);}
function parseBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',c=>{body+=c;if(body.length>1e6)req.destroy();});req.on('end',()=>{try{resolve(body?JSON.parse(body):{});}catch(e){reject(new Error('Invalid request.'));}});req.on('error',reject);});}

async function api(req,res){
  let body={}; try{body=await parseBody(req);}catch(e){return json(res,400,{message:e.message});}
  const db=readDb();
  try{
    if(req.url.startsWith('/api/auth/referrals') && req.method==='GET') {
      const urlObj=new URL(req.url,'http://localhost');
      const userId=String(urlObj.searchParams.get('userId')||'').trim();
      if(!userId) return json(res,400,{message:'User ID is required.'});
      const user=db.users.find(u=>String(u.userId)===userId);
      if(!user) return json(res,404,{message:'Account not found.'});
      const count=db.users.filter(u=>String(u.referredByPromoCode||'')===String(user.promoCode||user.userId)).length;
      return json(res,200,{referrals:count,userId:user.userId,promoCode:user.promoCode||user.userId});
    }
    if(req.url==='/api/auth/referral-migration' && req.method==='POST') {
      const candidates=Array.isArray(body.users)?body.users.slice(0,100):[];
      let migrated=0;
      for(const candidate of candidates){
        const userId=String(candidate&&candidate.userId||'').trim();
        const promoCode=String(candidate&&candidate.promoCode||userId).trim();
        const email=cleanEmail(candidate&&candidate.email);
        if(!/^\d{9}$/.test(userId)||promoCode!==userId||!/^\S+@\S+\.\S+$/.test(email)) continue;
        if(db.users.some(u=>String(u.userId)===userId||u.email===email)) continue;
        const legacyUser={userId,promoCode,email,phone:String(candidate.phone||'').trim(),username:String(candidate.username||email.split('@')[0]).trim(),verified:true,legacyReferralOnly:true,referredByPromoCode:String(candidate.referredByPromoCode||'').trim(),createdAt:new Date().toISOString()};
        const legacyPassword=String(candidate.password||'');
        if(legacyPassword.length>=8){
          const pw=await hashPassword(legacyPassword);
          legacyUser.passwordHash=pw.hash;
          legacyUser.passwordSalt=pw.salt;
          delete legacyUser.legacyReferralOnly;
        }
        db.users.push(legacyUser);
        migrated++;
      }
      if(migrated) writeDb(db);
      return json(res,200,{migrated});
    }
    if(req.url.startsWith('/api/auth/promo-code') && req.method==='GET') {
      const urlObj=new URL(req.url,'http://localhost');
      const promoCode=String(urlObj.searchParams.get('code')||'').trim();
      if(!promoCode) return json(res,400,{valid:false,message:'Promo code is required.'});
      const referrer=findReferrerByPromoCode(db,promoCode);
      if(!referrer) return json(res,404,{valid:false,message:'Invalid promo code.'});
      return json(res,200,{valid:true,promoCode});
    }
    if(req.url==='/api/auth/signup' && req.method==='POST'){
      const email=cleanEmail(body.email), phone=String(body.phone||'').trim(), password=String(body.password||''), referredByPromoCode=String(body.promoCode||'').trim();
      if(!email || !/^\S+@\S+\.\S+$/.test(email)) return json(res,400,{message:'Please enter a valid email address.'});
      if(password.length<8) return json(res,400,{message:'Password must be at least 8 characters.'});
      if(db.users.some(u=>u.email===email)) return json(res,409,{message:'An account with this email already exists.'});
      if(referredByPromoCode && !findReferrerByPromoCode(db,referredByPromoCode)) return json(res,400,{message:'Invalid promo code.'});
      const userId=makeUserId(db); const pw=await hashPassword(password);
      db.users.push({userId,promoCode:userId,email,phone,username:email.split('@')[0],passwordHash:pw.hash,passwordSalt:pw.salt,verified:true,referredByPromoCode,createdAt:new Date().toISOString()});
      writeDb(db);
      return json(res,201,{message:'Account created successfully.',userId,promoCode:userId,email,user:publicUser(db.users[db.users.length-1])});
    }
    if(req.url==='/api/auth/verify-email' && req.method==='POST'){
      const email=cleanEmail(body.email), code=String(body.code||'').trim(); const user=db.users.find(u=>u.email===email);
      if(!user) return json(res,404,{message:'Account not found.'});
      if(user.verified) return json(res,200,{message:'Email already verified.',user:publicUser(user)});
      if(codeExpired(user.verificationCreatedAt)) return json(res,400,{message:'Verification code has expired. Please sign up again.'});
      if(user.verificationCode!==code) return json(res,400,{message:'Incorrect verification code.'});
      user.verified=true; delete user.verificationCode; delete user.verificationCreatedAt; writeDb(db);
      return json(res,200,{message:'Email verified successfully.',user:publicUser(user)});
    }
    if(req.url==='/api/auth/login' && req.method==='POST'){
      const email=cleanEmail(body.email), password=String(body.password||''); const user=db.users.find(u=>u.email===email);
      if(!user) return json(res,401,{message:'Invalid email or password.'});
      if(!user.verified) return json(res,403,{message:'Please verify your email before logging in.'});
      const ok=await verifyPassword(password,user.passwordSalt,user.passwordHash); if(!ok)return json(res,401,{message:'Invalid email or password.'});
      return json(res,200,{message:'Login successful.',user:publicUser(user)});
    }
    if(req.url==='/api/auth/forgot-password/request' && req.method==='POST'){
      const email=cleanEmail(body.email), resetCode=String(body.resetCode||'').trim(), user=db.users.find(u=>u.email===email);
      if(!user) return json(res,404,{message:'No account was found with that email.'});
      if(!/^\d{6}$/.test(resetCode)) return json(res,400,{message:'Invalid reset code.'});
      user.resetCode=resetCode; user.resetCreatedAt=Date.now(); writeDb(db); try { await sendCodeEmail(email, resetCode, 'reset'); } catch (mailErr) { console.error('Reset email failed:', mailErr.message); delete user.resetCode; delete user.resetCreatedAt; writeDb(db); return json(res,503,{message:'Reset code could not be sent because the email service is not configured correctly.'}); } return json(res,200,{message:'Reset code sent.'});
    }
    if(req.url==='/api/auth/forgot-password/reset' && req.method==='POST'){
      const email=cleanEmail(body.email), code=String(body.code||'').trim(), newPassword=String(body.newPassword||''), user=db.users.find(u=>u.email===email);
      if(!user) return json(res,404,{message:'Account not found.'});
      if(newPassword.length<8) return json(res,400,{message:'Password must be at least 8 characters.'});
      if(codeExpired(user.resetCreatedAt)) return json(res,400,{message:'Reset code has expired.'});
      if(user.resetCode!==code) return json(res,400,{message:'Incorrect reset code.'});
      const pw=await hashPassword(newPassword); user.passwordHash=pw.hash; user.passwordSalt=pw.salt; delete user.resetCode; delete user.resetCreatedAt; writeDb(db); return json(res,200,{message:'Password reset successfully.'});
    }
    return json(res,404,{message:'Not found.'});
  }catch(err){console.error(err);return json(res,500,{message:'Server error. Please try again.'});}
}

const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.webmanifest':'application/manifest+json'};
function serve(req,res){
  let urlPath=decodeURIComponent((req.url||'/').split('?')[0]);
  if(urlPath==='/') urlPath='/index.html';
  if(urlPath==='/profile.html') urlPath='/user.html';
  const file=path.normalize(path.join(ROOT,urlPath));
  if(!file.startsWith(ROOT)) return json(res,403,{message:'Forbidden.'});
  fs.stat(file,(err,st)=>{if(err||!st.isFile())return json(res,404,{message:'Page not found.'}); const ext=path.extname(file).toLowerCase(); res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-cache':'public, max-age=86400'}); fs.createReadStream(file).pipe(res);});
}

ensureDb();
http.createServer((req,res)=>{if((req.url||'').startsWith('/api/')) api(req,res); else serve(req,res);}).listen(PORT,()=>console.log(`Triple Eagle Estates running on port ${PORT}`));
