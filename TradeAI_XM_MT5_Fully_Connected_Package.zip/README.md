# Trade AI — XM / MT5 connected package

This package is wired as **one Node.js web application**: the Node server serves the Android-friendly dashboard and all `/api/*` endpoints from the same origin. There is no Backend URL field in the dashboard.

## Important
The package can be fully wired, but it cannot log into an XM account by itself from an Android browser. The actual trading terminal must be running MetaTrader 5 on Windows (PC/VPS), logged into the XM account, with the included `TradeAI_Bridge.mq5` EA attached.

Connection path:

`Android browser → Node.js Trade AI server → MT5 Bridge EA → XM MT5 account`

The OpenAI analysis runs on the Node server. Secrets stay server-side.

## 1. Start the Node server

Requirements: Node.js 18+.

```bash
npm install
cp .env.example .env
# edit .env and set OPENAI_API_KEY and BOT_API_TOKEN
npm start
```

Open the **Node server URL** in your Android browser, for example `https://your-server.example.com/`. Do not open a static-only copy of `public/index.html` on EdgeOne; that will not provide `/api/login`.

Health check: open `/api/health`. It should return JSON with `ok: true`.

## 2. Connect MT5 / XM

1. Run Windows MT5 on a VPS/PC and log into the XM account.
2. Open MetaEditor and compile `mt5/TradeAI_Bridge.mq5`.
3. Attach the EA to an MT5 chart.
4. Set `ServerURL` to the exact HTTPS URL of this Node server.
5. Set `BotToken` to the same value as `BOT_API_TOKEN` in `.env`.
6. In MT5, allow WebRequest to the Node server URL.
7. Start with `AllowTrading=false`.

Once the EA is running, the dashboard should change from **MT5 offline** to **MT5 connected** and live account/market data should appear.

## 3. AI analysis

Set `OPENAI_API_KEY` on the Node server. `OPENAI_MODEL` is configurable in `.env`. If the key is missing, the dashboard remains usable but AI analysis returns a configuration error.

## 4. Live trading

The server defaults to `TRADING_MODE=DEMO`, and the EA defaults to `AllowTrading=false`. Do not enable live execution until you have verified the complete telemetry → AI → command → MT5 execution path with demo/forward testing.

The system does not guarantee profit.

## Access key

Default access key: `Dinesh Choudhry`. Change `APP_PASSWORD` in `.env` before production if you want a different key.
