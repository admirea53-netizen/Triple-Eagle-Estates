#property strict
#property version "1.00"
#include <Trade/Trade.mqh>
CTrade trade;

input string ServerURL="https://YOUR-TRADE-AI-SERVER.example.com";
input string BotToken="CHANGE_ME";
input string TradeSymbol="XAUUSD";
input int PollSeconds=2;
input double Lots=0.01;
input bool AllowTrading=false; // keep false until demo-tested

string Url(string path){ return ServerURL+path; }

string Http(string method,string path,string body=""){
   string headers="Content-Type: application/json\r\nAuthorization: Bearer "+BotToken+"\r\n";
   char data[],result[]; string result_headers;
   if(body!="") StringToCharArray(body,data,0,StringLen(body),CP_UTF8); else ArrayResize(data,0);
   ResetLastError();
   int code=WebRequest(method,Url(path),headers,8000,data,result,result_headers);
   if(code==-1){ Print("WebRequest failed: ",GetLastError()); return ""; }
   return CharArrayToString(result,0,-1,CP_UTF8);
}

int SymbolDigits(string symbol){ return (int)SymbolInfoInteger(symbol,SYMBOL_DIGITS); }
string Num(double x,int digits=5){ return DoubleToString(x,digits); }

string BuildTelemetry(){
   MqlTick tick; if(!SymbolInfoTick(TradeSymbol,tick)){ Print("No tick for ",TradeSymbol); return "{}"; }
   double bid=tick.bid, ask=tick.ask, mid=(bid+ask)/2.0;
   double balance=AccountInfoDouble(ACCOUNT_BALANCE), equity=AccountInfoDouble(ACCOUNT_EQUITY);
   string json="{\"market\":{"+
      "\"symbol\":\""+TradeSymbol+"\",\"price\":"+Num(mid,SymbolDigits(TradeSymbol))+",\"bid\":"+Num(bid,SymbolDigits(TradeSymbol))+",\"ask\":"+Num(ask,SymbolDigits(TradeSymbol))+"},"+
      "\"account\":{\"balance\":"+Num(balance,2)+",\"equity\":"+Num(equity,2)+"},"+
      "\"positions\":[";
   bool first=true;
   for(int i=PositionsTotal()-1;i>=0;i--){
      ulong ticket=PositionGetTicket(i); if(ticket==0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      if(!first) json+=","; first=false;
      string ps=PositionGetString(POSITION_SYMBOL);
      string typ=(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY?"BUY":"SELL");
      json+="{\"symbol\":\""+ps+"\",\"type\":\""+typ+"\",\"volume\":"+Num(PositionGetDouble(POSITION_VOLUME),2)+",\"profit\":"+Num(PositionGetDouble(POSITION_PROFIT),2)+"}";
   }
   json+="]}";
   return json;
}

string GetField(string json,string field){
   string key="\""+field+"\":"; int p=StringFind(json,key); if(p<0) return "";
   p+=StringLen(key); while(p<StringLen(json) && (StringGetCharacter(json,p)==' '||StringGetCharacter(json,p)=='\"')) p++;
   int e=p; while(e<StringLen(json)){ int c=StringGetCharacter(json,e); if(c==','||c=='}'||c==']'||c=='\"') break; e++; }
   return StringSubstr(json,p,e-p);
}

void ExecuteCommand(string json){
   string action=GetField(json,"action"); if(action=="") return;
   if(action=="CLOSE_ALL"){
      for(int i=PositionsTotal()-1;i>=0;i--){ ulong ticket=PositionGetTicket(i); if(ticket>0) trade.PositionClose(ticket); }
      Print("Close-all executed"); return;
   }
   if(!AllowTrading){ Print("Entry blocked: AllowTrading=false. Command=",action); return; }
   if(action!="BUY" && action!="SELL") return;
   string symbol=GetField(json,"symbol"); if(symbol=="") symbol=TradeSymbol;
   double slPts=StringToDouble(GetField(json,"slPoints"));
   double tpPts=StringToDouble(GetField(json,"tpPoints"));
   MqlTick t; if(!SymbolInfoTick(symbol,t)) return;
   double point=SymbolInfoDouble(symbol,SYMBOL_POINT);
   double sl=0,tp=0;
   if(action=="BUY"){
      if(slPts>0) sl=t.ask-slPts*point; if(tpPts>0) tp=t.ask+tpPts*point;
      trade.Buy(Lots,symbol,0,sl,tp,"TradeAI");
   }else{
      if(slPts>0) sl=t.bid+slPts*point; if(tpPts>0) tp=t.bid-tpPts*point;
      trade.Sell(Lots,symbol,0,sl,tp,"TradeAI");
   }
}

void Poll(){
   Http("POST","/api/mt5/telemetry",BuildTelemetry());
   string cmd=Http("GET","/api/mt5/command");
   if(cmd!=""){
      int p=StringFind(cmd,"\"command\":");
      if(p>=0){ string part=StringSubstr(cmd,p); if(StringFind(part,"null")<0) ExecuteCommand(part); }
   }
}

int OnInit(){
   if(ServerURL=="" || StringFind(ServerURL,"YOUR-TRADE-AI-SERVER")>=0){ Print("Set ServerURL to your Node.js Trade AI server URL."); return(INIT_PARAMETERS_INCORRECT); }
   if(BotToken=="" || BotToken=="CHANGE_ME"){ Print("Set BotToken to the same BOT_API_TOKEN used by the Node server."); return(INIT_PARAMETERS_INCORRECT); }
   if(!SymbolSelect(TradeSymbol,true)) Print("Could not select symbol: ",TradeSymbol);
   EventSetTimer(MathMax(1,PollSeconds));
   Print("TradeAI Bridge started. Add ServerURL to MT5 WebRequest allow-list.");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ EventKillTimer(); }
void OnTimer(){ Poll(); }
