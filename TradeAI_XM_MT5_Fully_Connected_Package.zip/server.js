import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import OpenAI from 'openai';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));

const cfg = {
  password: process.env.APP_PASSWORD || 'Dinesh Choudhry',
  token: process.env.BOT_API_TOKEN || 'change-this-long-random-token',
  mode: (process.env.TRADING_MODE || 'DEMO').toUpperCase(),
  model: process.env.OPENAI_MODEL || 'gpt-5.6-luna',
  maxRisk: Number(process.env.MAX_RISK_PER_TRADE_PCT || 0.5),
  maxDailyLoss: Number(process.env.MAX_DAILY_LOSS_PCT || 2),
  maxPositions: Number(process.env.MAX_OPEN_POSITIONS || 2),
  minConfidence: Number(process.env.MIN_AI_CONFIDENCE || 70),
  symbols: (process.env.SYMBOLS || 'XAUUSD,EURUSD,GBPUSD').split(',').map(s=>s.trim()).filter(Boolean)
};
const openai = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;

const sessions = new Set();

const MT5_STALE_MS = 7000;

let state = {
  authenticated:false,
  connected:false,
  lastMarket:null,
  history:[],
  account:null,
  positions:[],
  pendingCommand:null,
  lastDecision:null,
  events:[],
  paused:false,
  dayStartEquity:null,
  mode:cfg.mode
};

function logEvent(type,message,data={}){
  state.events.unshift({time:new Date().toISOString(),type,message,data});
  state.events=state.events.slice(0,100);
}
function dashboardAuth(req,res,next){
  const t=(req.headers.authorization||'').replace(/^Bearer\s+/,'');
  if(!t || !sessions.has(t)) return res.status(401).json({error:'Unauthorized'});
  next();
}
function botAuth(req,res,next){
  if(req.headers.authorization!==`Bearer ${cfg.token}`) return res.status(401).json({error:'Unauthorized'});
  next();
}

app.post('/api/login',(req,res)=>{
  if(req.body?.password!==cfg.password) return res.status(401).json({ok:false,error:'Invalid key'});
  const session = crypto.randomUUID();
  sessions.add(session);
  res.json({ok:true,session,mode:cfg.mode});
});

app.get('/api/health',(req,res)=>res.json({ok:true,service:'trade-ai',mode:state.mode,mt5Connected:state.connected}));

app.get('/api/state',dashboardAuth,(req,res)=>{
  if(state.lastTelemetryAt && Date.now()-state.lastTelemetryAt>MT5_STALE_MS) state.connected=false;
  res.json({
  mode:state.mode,paused:state.paused,connected:state.connected,
  market:state.lastMarket,history:state.history,account:state.account,positions:state.positions,
  decision:state.lastDecision,events:state.events.slice(0,30),
  limits:{maxRisk:cfg.maxRisk,maxDailyLoss:cfg.maxDailyLoss,maxPositions:cfg.maxPositions,minConfidence:cfg.minConfidence},
  setup:{serverReady:true,openaiConfigured:Boolean(openai),mt5TelemetryReceived:Boolean(state.lastTelemetryAt),lastTelemetryAt:state.lastTelemetryAt||null}
  });
});

// MT5 EA posts live quotes/account state here.
app.post('/api/mt5/telemetry',botAuth,(req,res)=>{
  const b=req.body||{};
  state.connected=true;
  state.lastTelemetryAt=Date.now();
  state.lastMarket=b.market||state.lastMarket;
  if(state.lastMarket?.price){ state.history.push({time:Date.now(),price:Number(state.lastMarket.price)}); if(state.history.length>240) state.history.shift(); }
  state.account=b.account||state.account;
  state.positions=Array.isArray(b.positions)?b.positions:state.positions;
  if(!state.account) state.account={};
  if(state.dayStartEquity===null && state.account?.equity) state.dayStartEquity=Number(state.account.equity);
  logEvent('MT5','Telemetry received',{symbol:state.lastMarket?.symbol});
  res.json({ok:true,paused:state.paused,command:state.pendingCommand});
});

// EA polls this endpoint for an approved command.
app.get('/api/mt5/command',botAuth,(req,res)=>{
  const cmd=state.pendingCommand;
  state.pendingCommand=null;
  res.json({ok:true,command:cmd,paused:state.paused});
});

app.post('/api/pause',dashboardAuth,(req,res)=>{state.paused=Boolean(req.body?.paused); logEvent('RISK',state.paused?'Trading paused':'Trading resumed'); res.json({ok:true,paused:state.paused});});
app.post('/api/close-all',dashboardAuth,(req,res)=>{state.pendingCommand={id:crypto.randomUUID(),action:'CLOSE_ALL'}; logEvent('COMMAND','Close-all requested'); res.json({ok:true});});

function riskAllows(action){
  if(state.paused) return {ok:false,reason:'Trading is paused'};
  if(action.action!=='BUY' && action.action!=='SELL') return {ok:false,reason:'Unsupported entry action'};
  if(state.positions.length>=cfg.maxPositions) return {ok:false,reason:'Maximum open positions reached'};
  if(state.account?.equity && state.dayStartEquity){
    const dd=((state.dayStartEquity-Number(state.account.equity))/state.dayStartEquity)*100;
    if(dd>=cfg.maxDailyLoss) return {ok:false,reason:`Daily loss limit reached (${dd.toFixed(2)}%)`};
  }
  return {ok:true};
}

app.post('/api/analyze',dashboardAuth,async(req,res)=>{
  if(!openai) return res.status(503).json({error:'OPENAI_API_KEY is not configured'});
  const market=req.body?.market || state.lastMarket;
  if(!market) return res.status(400).json({error:'No market data available'});
  const prompt={
    task:'Analyze a forex/CFD setup as a decision-support layer. Do not promise profit. Return HOLD unless the evidence is strong.',
    constraints:{allowedActions:['BUY','SELL','HOLD'],minConfidence:cfg.minConfidence,maxRiskPct:cfg.maxRisk},
    market,
    account:{equity:state.account?.equity,balance:state.account?.balance,positions:state.positions.length},
    indicators:market.indicators||{},
    recentPrices:state.history.slice(-60)
  };
  try{
    const response=await openai.responses.create({
      model:cfg.model,
      input:[
        {role:'system',content:'You are a conservative trading analysis engine. You do not guarantee returns. Never invent prices or data. Prefer HOLD when evidence is mixed. Output only JSON matching the requested fields.'},
        {role:'user',content:JSON.stringify(prompt)}
      ],
      text:{format:{type:'json_schema',name:'trade_decision',strict:true,schema:{type:'object',properties:{action:{type:'string',enum:['BUY','SELL','HOLD']},confidence:{type:'number',minimum:0,maximum:100},reason:{type:'string'},stopLossPoints:{type:'number',minimum:0},takeProfitPoints:{type:'number',minimum:0}},required:['action','confidence','reason','stopLossPoints','takeProfitPoints'],additionalProperties:false}}}
    });
    const decision=JSON.parse(response.output_text);
    state.lastDecision={...decision,time:new Date().toISOString(),symbol:market.symbol};
    logEvent('AI',`${decision.action} ${decision.confidence}%`,decision);
    if(decision.action==='BUY'||decision.action==='SELL'){
      const risk=riskAllows(decision);
      if(risk.ok && decision.confidence>=cfg.minConfidence && state.mode==='LIVE'){
        state.pendingCommand={id:crypto.randomUUID(),action:decision.action,symbol:market.symbol,slPoints:decision.stopLossPoints,tpPoints:decision.takeProfitPoints};
        logEvent('EXECUTION','Approved entry command queued',state.pendingCommand);
      } else {
        logEvent('RISK','AI signal blocked',{reason:risk.reason||`Confidence below ${cfg.minConfidence}% or mode is DEMO`});
      }
    }
    res.json({ok:true,decision,mode:state.mode});
  }catch(e){
    console.error(e);
    res.status(500).json({error:'AI analysis failed'});
  }
});

app.use((req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=Number(process.env.PORT||8080);
if(!Number.isFinite(port)||port<1||port>65535) throw new Error('Invalid PORT');
if(cfg.token==='change-this-long-random-token') console.warn('WARNING: change BOT_API_TOKEN before connecting MT5.');
if(!openai) console.warn('WARNING: OPENAI_API_KEY is not configured; AI analysis will remain disabled.');
app.listen(port,()=>console.log(`Trade AI server listening on port ${port}`));
